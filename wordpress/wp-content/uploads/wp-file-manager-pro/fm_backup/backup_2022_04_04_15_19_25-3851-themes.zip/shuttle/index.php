<?php
/**
 * The main template file.
 *
 * @package ShuttleThemes
 */

	include( get_archive_template() );

?>