<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:19:{s:6:"apiKey";s:160:"5cf358e7e02712f8059ea81a484a016be5751b5b0cc153c056de918ec45f092671e5b1e387d806a6b0319b6c9c2c8c82f3540aed2d5986e0de5263cd7b3082f214ca919b1e43b63845ae1f06ee4d16c8";s:6:"isPaid";b:0;s:7:"siteURL";N;s:7:"homeURL";N;s:14:"whitelistedIPs";N;s:9:"howGetIPs";N;s:25:"howGetIPs_trusted_proxies";N;s:13:"pluginABSPATH";N;s:11:"other_WFNet";b:1;s:9:"serverIPs";N;s:15:"blockCustomText";N;s:13:"timeoffset_wf";N;s:23:"advancedBlockingEnabled";N;s:21:"betaThreatDefenseFeed";N;s:20:"disableWAFIPBlocking";N;s:13:"patternBlocks";N;s:13:"countryBlocks";N;s:11:"otherBlocks";N;s:8:"lockouts";N;}