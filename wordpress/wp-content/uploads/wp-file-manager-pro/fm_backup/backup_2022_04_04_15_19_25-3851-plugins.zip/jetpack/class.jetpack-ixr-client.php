<?php
/**
 * Deprecated since 7.7.
 *
 * @deprecated
 * @package automattic/jetpack
 */

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
_deprecated_file( basename( __FILE__ ), 'jetpack-7.7' );
