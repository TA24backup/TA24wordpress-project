<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:12:{s:22:"attackDataNextInterval";N;s:16:"rulesLastUpdated";N;s:12:"premiumCount";N;s:12:"filePatterns";N;s:24:"filePatternCommonStrings";N;s:18:"filePatternIndexes";N;s:21:"signaturesLastUpdated";N;s:21:"signaturePremiumCount";N;s:23:"createInitialRulesDelay";N;s:10:"watchedIPs";b:0;s:15:"blockedPrefixes";N;s:21:"blacklistAllowedCache";N;}